<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>ERICSSON | LOGISTIC TOOL</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="css/base.css">  
   <link rel="stylesheet" href="css/main.css">
   <link rel="stylesheet" href="css/vendor.css">   
   <link rel="stylesheet" href="fonts/_ericssonfonts.css">    

   <style type="text/css">
        <?php
          $ekunbarbg = range(1, 11);
          shuffle($ekunbarbg);
          foreach ($ekunbarbg as $ekunbarbg) {
              echo "
      #intro {
        background: #090909 url(images/bg/".$ekunbarbg.".jpg) no-repeat center;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        background-size: cover;
        width: 100%;
        height: 100%;
        min-height: 720px;
        display: table;
        position: relative;
      }";
          }
        ?>
        <?php
          $ekunbarfeatbg = range(1, 4);
          shuffle($ekunbarfeatbg);
          foreach ($ekunbarfeatbg as $ekunbarfeatbg) {
              echo "
      #features {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), #14181E url(images/bg/".$ekunbarfeatbg.".jpg) no-repeat center;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        background-size: cover;
        background-opacity: 0.7;
      }";
          }
        ?>
      h1, h2, h3, h4, h5, .widget, .x-navigation, .breadcrumb, .mb-title, .ericssonfont {
        font-family: 'ericsson_capital', Arial !important;
        font-weight: 400;
      }
      .treeview-menu, .copyright, .footer-main p {
        font-family: arial,helvetica,clean,sans-serif !important;
      }
      .main-navigation {
        font-family: arial,helvetica,clean,sans-serif !important;
        font-size: 18px;
        font-weight: 400;
        font-style: none;
      }
   </style>

   <!-- script
   ================================================== -->
	<script src="js/modernizr.js"></script>

   <!-- favicons
	================================================== -->
	<link rel="icon" type="image/png" href="http://eidwhd.com/assets/coroowicaksono/img/ericsson_logo.ico">

</head>

<body id="top">

	<!-- header 
   ================================================== -->
   <header>

   	<div class="row">

   		<div class="logo">
	         <a href="index.html">ERICSSON TOOL</a>
	      </div>

	   	<nav id="main-nav-wrap">
				<ul class="main-navigation">
					<li class="current"><a class="smoothscroll"  href="#intro" title="">Home</a></li>
					<li><a class="smoothscroll"  href="#process" title="">Tool Features</a></li>
          <li><a href="http://www.ericsson.com/thinkingahead/networked_society/stories/#/film" target="_blank" title="">Network Society</a></li>
					<!--<li><a class="smoothscroll"  href="#features" title="">Features</a></li>
					<li><a class="smoothscroll"  href="#faq" title="">FAQ</a></li>					-->
					<li class="highlight with-sep"><a class="smoothscroll" href="#ekunbarloginform" title="Login">Sign In</a></li>					
				</ul>
			</nav>

			<a class="menu-toggle" href="#"><span>Menu</span></a>
   		
   	</div>   	
   	
   </header> <!-- /header -->

	<!-- intro section
   ================================================== -->
   <section id="intro">

   	<div class="shadow-overlay"></div>

   	<div class="intro-content">
   		<div class="row">

   			<div class="col-twelve">

	   			<div class='video-link'>
	   				<a href="#video-popup"><img src="images/play-button.png" alt=""></a>
	   			</div>

	   			<h5>Hello welcome to EIDWHD.COM</h5>
	   			<h2>Our awesome app will make your life a lot easier.</h2>

	   			<a class="button stroke smoothscroll ericssonfont" href="#ekunbarloginform" title="">Sign In</a>

	   		</div>  
   			
   		</div>   		 		
   	</div> 

   	<!-- Modal Popup
	   ========================================================= -->

      <div id="video-popup" class="popup-modal mfp-hide">

		   <div class="fluid-video-wrapper">
            <iframe src="https://www.youtube.com/embed/vZgYEzfSLVg?title=0&amp;byline=0&amp;portrait=0&amp;color=faec09" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> 
         </div>		     

         <a class="close-popup">Close</a>         

	   </div> <!-- /video-popup -->  	 	

   </section> <!-- /intro -->

   <div class="line-ericsson"></div>
   <!-- Process Section
   ================================================== -->
   <section id="process">  

   	<div class="row section-intro">
   		<div class="col-twelve with-bottom-line">

   			<h5>ERICSSON TOOLS</h5>
   			<h1>Why using eidwhd.com ?</h1>

   			<p class="lead">EIDWHD.COM – it's a Networked Society for Logistic Department. A society where everything that benefits focusing for logistic will be connected. To understand the opportunities and challenges, explore our insights about logistic development and what people in logistic department want, as well as the best in tomorrow's business process and technology.<br/><br/>By using this tool, you can also ...</p>

   		</div>   		
   	</div>

   	<div class="row process-content">

   		<a class="smoothscroll" href="#ekunbarloginform" title="Responsive"><div class="image-part"></div></a> 			

   	</div> <!-- /process-content --> 

   </section> <!-- /process-->    


   <!-- features Section
   ================================================== -->
	<section id="features">

   	<div class="row features-content">

   		<div class="features-list block-1-3 block-s-1-2 block-tab-full group">

	      	<div class="bgrid feature">	

	      		<span class="icon"><i class="icon-window"></i></span>            

	            <div class="service-content">	

	            	 <h3 class="h03" style="color:#FFF">Any Device View</h3>

		            <p>Responsive web design allows a site’s layout to change as the screen size being used to view that site changes. A wide screen display can receive a site design with multiple columns of content while a small screen can have that same content presented in a single column with text and links that are appropriately sized to be read and used on that smaller display.
	         		</p>
	         		
	         	</div> 	         	 

				</div> <!-- /bgrid -->

				<div class="bgrid feature">	
          <br/><br/><br/>
					<span class="icon"><i class="icon-layers"></i></span>                          

	            <div class="service-content">
	            	<h3 class="h03" style="color:#FFF">Connected Tools</h3>  

		            <p>Warehousing & Distribution has a lot of tools. Eidwhd.com help you to quickly find the data that you are find on those tools and stay up to date with the helicopter view. Helicopter visualization enhance your reading experience for data, for instance, by helping you take a look performance for vendor on weekly based.
	         		</p>

	         		
	            </div>	                          

			   </div> <!-- /bgrid -->

			   <div class="bgrid feature">

			   	<span class="icon"><i class="icon-paint-brush"></i></span>		            

	            <div class="service-content">
	            	<h3 class="h03" style="color:#FFF">Stylish Design</h3>

		            <p>As a market leader, Ericsson strives to lead industry transformation through mobility. Telling the story of our growing product portfolio and our latest projects is one way of communicating who we are and what we do.
                 Eidwhd.com using Ericsson identity in scope of logotype, graphics, images, print and words.
	        			</p> 

	        			
	            </div> 	            	               

			   </div> <!-- /bgrid -->

	      </div> <!-- features-list -->
   		
   	</div> <!-- features-content -->
		
	</section> <!-- /features -->
	

	<!-- pricing
   ================================================== -->

   <section id="ekunbarloginform">

   	<div class="row section-intro">
   		<div class="col-twelve with-bottom-line">

   			<h5>LOGIN FORM</h5>
   			<h2 class="h01 lead">WELCOME & PLEASE LOGIN</h2>

   		</div>   		
   	</div>

    <div class="row section-ads">

       <div class="col-twelve"> 

          <div class="ad-content">

            <form class="wellekunbar" method="POST" action="index.php/frontpage/login">
                <!--<label for="exampleInputEmail1">Username</label>-->
                <input type="text" class="inputannya" id="user" name="user" placeholder="Username">
              </div>
              <div class="form-group">
                <!--<label for="exampleInputPassword1">Password</label>-->
                <input type="password" class="inputannya" id="password" name="password" placeholder="Password">
              </div>
              <button type="submit" class="button large round">LOGIN</button>
             </form>          

      </div>

    </div> <!-- /section-ads --> 

   </section> <!-- /pricing --> 

   <!-- cta
   ================================================== -->
   <section id="cta">

   	<div class="row cta-content">

   		<div class="col-twelve">

   			<h2 style='color:#FFF'>Still don't have any account ?</h2>

   			<p class="lead" style="font-size:12px">Request by Mail :</p>

   			<ul class="stores">
   				<li class="app-store">
   					<a href="mailto:immanuelhendarto@ericsson.com" class="button stroke smoothscroll ericssonfont" style="line-height: 12px;" title="">
   						<i class="icon ion-paper-airplane"></i>Imanuel Hendarto <br/><span style='font-size:10px;margin-top:-20px'>Line Manager WHD</span>
   					</a>
   				</li>
   				<li class="windows-store">
   					<a href="mailto:kuncoro.wicaksono.adi.baroto@ericsson.com" class="button stroke smoothscroll ericssonfont" style="line-height: 12px;" title="">
   						<i class="icon ion-paper-airplane"></i>Kuncoro Wicaksono <br/><span style='font-size:10px'>Developer WHD</span></a>
   					</li>
   			</ul>

   		</div>

   	</div> <!-- /cta-content -->

   </section> <!-- /cta -->


   <!-- footer
   ================================================== -->
   <footer>

   	<div class="footer-main">

   		<div class="row">  

	      	<div class="col-four tab-full mob-full footer-info">            

	            <div class="footer-logo"></div>

	            <p>
		        	ERICSSON INDONESIA,<br>
            	PT Wismah Pondok Indah 2nd floor<br>
              Jakarta 12310<br>
		        	Indonesia &nbsp; +62 21 769 2222
		        	</p>

		      </div> <!-- /footer-info -->

	      	<div class="col-four tab-1-4 mob-1-6 site-links">

	      		<h4>Ericsson Links</h4>

	      		<ul>
	      			<li><a href="http://www.ericsson.com/id/thecompany/company_facts" target="_blank">Company Facts</a></li>
  						<li><a href="http://www.ericsson.com/id/thecompany/corporate_governance" target="_blank">Corporate Governance</a></li>
  						<li><a href="http://www.ericsson.com/id/thecompany/investors" target="_blank">Investors</a></li>
  						<li><a href="http://www.ericsson.com/id/thecompany/press" target="_blank">Press</a></li>
  						<li><a href="http://www.ericsson.com/id/thecompany/our_publications" target="_blank">Publication</a></li>
  					</ul>

	      	</div> <!-- /site-links -->  

	      	<div class="col-four tab-1-4 mob-1-6 social-links">

	      		<h4>Thinking a Head</h4>

	      		<ul>
	      			<li><a href="http://www.ericsson.com/id/thinkingahead/networked_society" target="_blank">Network Society</a></li>
  						<li><a href="http://www.ericsson.com/id/thinkingahead/innovation" target="_blank">Innovation</a></li>
              <li><a href="http://www.ericsson.com/id/thinkingahead/innovation/technology-research-insights" target="_blank">Ericsson Technology</a></li>
  						<li><a href="http://www.ericsson.com/id/thinkingahead/consumerlab" target="_blank">Ericsson Consumer Lab</a></li>
  						<li><a href="http://www.ericsson.com/id/thinkingahead/innovation/visionary-ideas" target="_blank">Ericsson Vision</a></li>
  					</ul>
	      	           	
	      	</div> <!-- /social -->        

	      </div> <!-- /row -->

   	</div> <!-- /footer-main -->


      <div class="footer-bottom">

      	<div class="row">

      		<div class="col-twelve">
	      		<div class="copyright">
		         	<span>© Copyright Ericsson 1994-<?php echo date("Y");?>.</span> 
		         	<span>Design by <a href="http://www.coroowicaksono.com/">Kuncoro Wicaksono</a></span>		         	
		         </div>

		         <div id="go-top" style="display: block;">
		            <a class="smoothscroll" title="Back to Top" href="#top"><i class="icon ion-android-arrow-up"></i></a>
		         </div>         
	      	</div>

      	</div> <!-- /footer-bottom -->     	

      </div>

   </footer>  

   <!--<div id="preloader"> 
    	<div id="loader"></div>
   </div> -->

   <!-- Java Script
   ================================================== --> 
   <script src="js/jquery-1.11.3.min.js"></script>
   <script src="js/jquery-migrate-1.2.1.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>

</body>

</html>